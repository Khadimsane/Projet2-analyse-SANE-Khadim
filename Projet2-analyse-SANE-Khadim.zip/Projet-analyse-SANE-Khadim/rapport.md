# Rapport d'analyse — Journaux du pare-feu

**Auteur : SANE Khadim** · Période analysée : une semaine de connexions · Source : `data/logs_reseau.csv`

> ⚠️ Les valeurs entre `[[ ]]` sont à remplacer par les chiffres affichés par `python analyse.py`
> (console + `resultats.json`). Supprimer cette note avant le rendu.

## 1. Résumé

Après nettoyage (suppression des doublons exacts, `protocol` en majuscules, `bytes_sent` manquants
remplacés par la médiane), il reste **[[nb_lignes_apres_nettoyage]] connexions**. Le trafic est dominé par le
port **[[top_port]]** ([[nom du service]]), ce qui est cohérent avec une activité web normale.
**[[taux_deny_pct]] %** des connexions sont bloquées par le pare-feu. Deux comportements sortent
nettement du lot : un **balayage de ports** et une **émission anormale de données** (voir ci-dessous).
Le trafic des objets IoT ([[caméras / capteurs]]) mérite aussi une attention particulière.

## 2. Comportements suspects

### 2.1 Scan de ports — `[[ip_scanner]]`

- **Preuve :** cette IP a contacté **[[N]] ports de destination distincts** en [[M]] connexions,
  contre [[K]] ports distincts pour l'IP suivante ; [[X]] % de ses connexions sont en `DENY`.
- **Graphique :** `figures/05_scan_ports_par_ip.png` (barre rouge).
- **Interprétation :** contacter autant de ports différents en peu de temps est la signature d'une
  phase de reconnaissance (type Nmap) visant à trouver des services exposés.

![Ports distincts par IP](figures/05_scan_ports_par_ip.png)

### 2.2 Exfiltration potentielle — `[[ip_exfiltration]]`

- **Preuve :** cette IP a envoyé **[[Y]] octets** au total, soit [[Z]] % du volume global, alors que la
  médiane par IP est de [[W]] octets. Appareil concerné : [[device_type]] ; ports utilisés : [[ports]].
- **Graphique :** `figures/03_octets_par_appareil.png`.
- **Interprétation :** un volume sortant aussi disproportionné est compatible avec un vol de données
  (ou une machine compromise qui envoie son contenu vers l'extérieur).

![Octets par appareil](figures/03_octets_par_appareil.png)

## 3. Autres observations

![Top ports](figures/01_top_ports.png)
![Connexions par heure](figures/02_connexions_par_heure.png)
![ALLOW / DENY](figures/04_allow_deny.png)

- **Telnet (port 23)** : [[T]] connexions, dont [[A]] autorisées (`ALLOW`). Protocole non chiffré, à proscrire.
- **Activité horaire** : [[décrire les pics / l'activité hors heures de bureau, s'il y en a]].

## 4. Recommandations de sécurité

1. **Bloquer le scan à la source** : ajouter une règle de pare-feu qui met en liste noire toute IP
   contactant plus de ~20 ports distincts en moins d'une minute (limitation de débit / IPS), et bloquer
   `[[ip_scanner]]` immédiatement.
2. **Fermer Telnet (port 23)** : refuser tout trafic vers le port 23 et le remplacer par SSH (port 22)
   avec authentification par clés, notamment pour les caméras et capteurs.
3. **Segmenter les objets IoT** : placer caméras et capteurs dans un VLAN dédié, avec des règles
   autorisant uniquement ce qui est nécessaire (par ex. MQTT 1883 vers le broker interne) et aucun accès
   libre vers Internet ni vers le VLAN des serveurs.
4. **Surveiller et limiter le trafic sortant** : alerte automatique quand une IP dépasse un seuil
   d'octets envoyés ; isoler et analyser la machine `[[ip_exfiltration]]` (recherche de malware,
   changement des identifiants).
5. **Journalisation et alertes** : centraliser les logs (SIEM ou script planifié comme `analyse.py`)
   pour détecter ces comportements chaque jour plutôt qu'une fois par semaine.
