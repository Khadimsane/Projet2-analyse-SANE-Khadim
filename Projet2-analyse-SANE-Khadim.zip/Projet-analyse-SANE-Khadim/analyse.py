"""Analyse des journaux d'un pare-feu (Projet 1 - L3 Réseaux / Sécurité / IoT).

Auteur : SANE Khadim
Lancement : python analyse.py

Le script :
  1. lit data/logs_reseau.csv ;
  2. nettoie les données (doublons, casse de protocol, bytes_sent manquants) ;
  3. calcule les 5 résultats demandés et les écrit dans resultats.json ;
  4. enregistre des figures PNG dans figures/ ;
  5. affiche des indicateurs complémentaires (utiles pour rédiger rapport.md).
"""

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")  # pas d'écran nécessaire : on enregistre seulement les images
import matplotlib.pyplot as plt
import pandas as pd

RACINE = Path(__file__).resolve().parent
FICHIER_DONNEES = RACINE / "data" / "logs_reseau.csv"
FICHIER_RESULTATS = RACINE / "resultats.json"
DOSSIER_FIGURES = RACINE / "figures"

NOMS_PORTS = {
    22: "SSH", 23: "Telnet", 53: "DNS", 80: "HTTP",
    443: "HTTPS", 1883: "MQTT", 3389: "RDP", 8080: "HTTP-alt",
}


def charger_donnees(chemin: Path) -> pd.DataFrame:
    """Lit le fichier CSV brut."""
    return pd.read_csv(chemin)


def nettoyer(df: pd.DataFrame) -> pd.DataFrame:
    """Nettoyage demandé : doublons, protocol en majuscules, bytes_sent manquants."""
    # 1. doublons exacts
    df = df.drop_duplicates().copy()

    # 2. protocol en MAJUSCULES (strip par sécurité contre les espaces parasites)
    df["protocol"] = df["protocol"].astype("string").str.strip().str.upper()
    df["action"] = df["action"].astype("string").str.strip().str.upper()

    # 3. bytes_sent manquants -> médiane (calculée après suppression des doublons)
    df["bytes_sent"] = pd.to_numeric(df["bytes_sent"], errors="coerce")
    mediane = df["bytes_sent"].median()
    df["bytes_sent"] = df["bytes_sent"].fillna(mediane)

    # Confort pour les figures : vrai type date/heure
    df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
    return df


def calculer_resultats(df: pd.DataFrame) -> dict:
    """Calcule les 5 résultats demandés."""
    top_port = int(df["dst_port"].value_counts().idxmax())
    taux_deny = round(float((df["action"] == "DENY").mean() * 100), 2)
    ip_scanner = str(df.groupby("src_ip")["dst_port"].nunique().idxmax())
    ip_exfiltration = str(df.groupby("src_ip")["bytes_sent"].sum().idxmax())

    return {
        "nb_lignes_apres_nettoyage": int(len(df)),
        "top_port": top_port,
        "taux_deny_pct": taux_deny,
        "ip_scanner": ip_scanner,
        "ip_exfiltration": ip_exfiltration,
    }


def _enregistrer(fig, nom: str) -> None:
    DOSSIER_FIGURES.mkdir(exist_ok=True)
    fig.tight_layout()
    fig.savefig(DOSSIER_FIGURES / nom, dpi=130)
    plt.close(fig)


def faire_figures(df: pd.DataFrame, res: dict) -> None:
    """Génère 5 figures PNG avec titre et axes lisibles."""
    # 1. Top 10 des ports de destination
    top = df["dst_port"].value_counts().head(10)
    etiquettes = [f"{p}\n{NOMS_PORTS.get(int(p), '')}".strip() for p in top.index]
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.bar(etiquettes, top.values, color="#2a6fb0")
    ax.set_title("Top 10 des ports de destination")
    ax.set_xlabel("Port de destination")
    ax.set_ylabel("Nombre de connexions")
    _enregistrer(fig, "01_top_ports.png")

    # 2. Connexions par heure de la journée
    par_heure = df["timestamp"].dt.hour.value_counts().sort_index()
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.plot(par_heure.index, par_heure.values, marker="o", color="#c0392b")
    ax.set_xticks(range(0, 24, 2))
    ax.set_title("Connexions par heure de la journée")
    ax.set_xlabel("Heure (0-23)")
    ax.set_ylabel("Nombre de connexions")
    ax.grid(alpha=0.3)
    _enregistrer(fig, "02_connexions_par_heure.png")

    # 3. Volume d'octets envoyés par type d'appareil
    volume = df.groupby("device_type")["bytes_sent"].sum().sort_values(ascending=False)
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.bar(volume.index, volume.values / 1e6, color="#27ae60")
    ax.set_title("Volume d'octets envoyés par type d'appareil")
    ax.set_xlabel("Type d'appareil")
    ax.set_ylabel("Octets envoyés (Mo)")
    _enregistrer(fig, "03_octets_par_appareil.png")

    # 4. Répartition ALLOW / DENY
    actions = df["action"].value_counts()
    fig, ax = plt.subplots(figsize=(6, 6))
    ax.pie(actions.values, labels=actions.index, autopct="%1.1f%%",
           colors=["#27ae60", "#c0392b"][: len(actions)], startangle=90)
    ax.set_title(f"Répartition ALLOW / DENY (DENY = {res['taux_deny_pct']} %)")
    _enregistrer(fig, "04_allow_deny.png")

    # 5. Top 10 des IP sources par nombre de ports distincts contactés (scan)
    ports_distincts = (df.groupby("src_ip")["dst_port"].nunique()
                       .sort_values(ascending=False).head(10))
    couleurs = ["#c0392b" if ip == res["ip_scanner"] else "#7f8c8d"
                for ip in ports_distincts.index]
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.bar(ports_distincts.index, ports_distincts.values, color=couleurs)
    ax.set_title("Ports distincts contactés par IP source (top 10)")
    ax.set_xlabel("Adresse IP source")
    ax.set_ylabel("Nombre de ports distincts")
    plt.setp(ax.get_xticklabels(), rotation=45, ha="right")
    _enregistrer(fig, "05_scan_ports_par_ip.png")


def afficher_indicateurs(df: pd.DataFrame, res: dict) -> None:
    """Chiffres de preuve à recopier dans rapport.md (non écrits dans resultats.json)."""
    scanner = df[df["src_ip"] == res["ip_scanner"]]
    exfil = df[df["src_ip"] == res["ip_exfiltration"]]
    total_octets = df["bytes_sent"].sum()
    octets_par_ip = df.groupby("src_ip")["bytes_sent"].sum()

    print("\n=== Indicateurs complémentaires ===")
    print(f"Période : {df['timestamp'].min()} -> {df['timestamp'].max()}")
    print(f"Appareils : {df['device_type'].value_counts().to_dict()}")
    print(f"Protocoles : {df['protocol'].value_counts().to_dict()}")

    print(f"\n[Scanner] {res['ip_scanner']} : {scanner['dst_port'].nunique()} ports distincts, "
          f"{len(scanner)} connexions, DENY = {(scanner['action'] == 'DENY').mean() * 100:.1f} %, "
          f"appareil(s) : {scanner['device_type'].unique().tolist()}")
    print(f"  Ports distincts de l'IP suivante : "
          f"{df.groupby('src_ip')['dst_port'].nunique().sort_values(ascending=False).iloc[1]}")

    print(f"\n[Exfiltration] {res['ip_exfiltration']} : {exfil['bytes_sent'].sum():,.0f} octets "
          f"({exfil['bytes_sent'].sum() / total_octets * 100:.1f} % du total), "
          f"médiane des IP = {octets_par_ip.median():,.0f} octets")
    print(f"  Ports de destination les plus utilisés : "
          f"{exfil['dst_port'].value_counts().head(3).to_dict()}")
    print(f"  Appareil(s) : {exfil['device_type'].unique().tolist()}, "
          f"heures d'activité : {sorted(exfil['timestamp'].dt.hour.dropna().unique().astype(int).tolist())}")

    telnet = df[df["dst_port"] == 23]
    print(f"\n[Telnet 23] {len(telnet)} connexions, ALLOW = {(telnet['action'] == 'ALLOW').sum()}, "
          f"par appareil : {telnet['device_type'].value_counts().to_dict()}")

    iot = df[df["device_type"].isin(["camera_IoT", "capteur_IoT"])]
    print(f"[IoT] ports de destination : {iot['dst_port'].value_counts().head(5).to_dict()}")
    print(f"[SSH 22] connexions autorisées : "
          f"{((df['dst_port'] == 22) & (df['action'] == 'ALLOW')).sum()}")


def main() -> None:
    if not FICHIER_DONNEES.exists():
        raise SystemExit(f"Fichier introuvable : {FICHIER_DONNEES}")

    brut = charger_donnees(FICHIER_DONNEES)
    df = nettoyer(brut)
    print(f"Lignes brutes : {len(brut)} -> après nettoyage : {len(df)}")

    res = calculer_resultats(df)
    with open(FICHIER_RESULTATS, "w", encoding="utf-8") as f:
        json.dump(res, f, indent=2, ensure_ascii=False)
    print("Résultats :", json.dumps(res, ensure_ascii=False))

    faire_figures(df, res)
    print(f"Figures enregistrées dans {DOSSIER_FIGURES}")

    afficher_indicateurs(df, res)


if __name__ == "__main__":
    main()
